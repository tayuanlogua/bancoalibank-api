import jwt from "jsonwebtoken";
import { SECRET } from "../config.js";
import User from "../models/User.js";
import Role from "../models/Role.js";

// Función para verificar el token
const verifyToken = async (token) => {
  if (!token) {
    throw new Error("No token provided");
  }

  try {
    const decoded = jwt.verify(token, SECRET);
    return decoded.id;
  } catch (error) {
    throw new Error("Unauthorized!");
  }
};

// Función para comprobar si el usuario es moderador
const isModerator = async (userId) => {
  try {
    const user = await User.findById(userId);
    const roles = await Role.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].name === "moderator") {
        return true;
      }
    }

    return false;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Función para comprobar si el usuario es administrador
const isAdmin = async (userId) => {
  try {
    const user = await User.findById(userId);
    const roles = await Role.find({ _id: { $in: user.roles } });

    for (let i = 0; i < roles.length; i++) {
      if (roles[i].name === "admin") {
        return true;
      }
    }

    return false;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Ejemplo de uso
(async () => {
  try {
    // Simular un token de usuario válido
    const token = "tu_token_de_usuario";

    // Verificar el token
    const userId = await verifyToken(token);

    // Comprobar si el usuario es moderador
    const isModeratorUser = await isModerator(userId);
    if (isModeratorUser) {
      console.log("El usuario es moderador");
    } else {
      console.log("El usuario no es moderador");
    }

    // Comprobar si el usuario es administrador
    const isAdminUser = await isAdmin(userId);
    if (isAdminUser) {
      console.log("El usuario es administrador");
    } else {
      console.log("El usuario no es administrador");
    }
  } catch (error) {
    console.error(error.message);
  }
})();

