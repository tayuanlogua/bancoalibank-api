// Importar las dependencias necesarias
import express from 'express';
import { checkExistingUser } from './tu_archivo.js';

// Crear una instancia de Express
const app = express();

// Middleware para parsear el cuerpo de la solicitud en JSON
app.use(express.json());

// Ruta para crear un nuevo usuario
app.post('/users', checkExistingUser, (req, res) => {
  // Aquí se procede a crear el usuario ya que el middleware checkExistingUser ha pasado
  res.send('Usuario creado exitosamente');
});

// Escuchar en un puerto
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});
import { checkExistingRole } from "./tu_archivo.js";

// Simular una solicitud HTTP con roles proporcionados en el cuerpo
const req = {
  body: {
    roles: ["admin", "user", "moderator"]
  }
};

// Simular un objeto de respuesta vacío
const res = {};

// Función para simular el paso al siguiente middleware
const next = () => {
  console.log("Roles verificados correctamente");
};

// Llamar al middleware checkExistingRole con la solicitud, respuesta y función next simuladas
checkExistingRole(req, res, next);
