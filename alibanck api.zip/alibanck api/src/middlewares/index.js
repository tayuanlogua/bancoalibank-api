import { authJwt, verifySignup } from "./tus_archivos.js";

// Ejemplo de uso de authJwt
const token = "tu_token_de_usuario";

try {
  const userId = authJwt.verifyToken(token);
  console.log("ID de usuario verificado:", userId);
} catch (error) {
  console.error("Error al verificar el token:", error.message);
}

// Ejemplo de uso de verifySignup
const userData = {
  username: "ejemplo",
  email: "ejemplo@example.com",
  password: "password123",
  roles: ["user"],
};

try {
  verifySignup.checkDuplicateUsernameOrEmail(userData);
  console.log("Usuario verificado correctamente");
} catch (error) {
  console.error("Error al verificar el usuario:", error.message);
}

