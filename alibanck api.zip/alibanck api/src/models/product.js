import { Schema, model } from "mongoose";

// Definición del esquema para el modelo de Producto
const productSchema = new Schema({
    name: String,           // Nombre del producto (tipo String)
    category: String,       // Categoría del producto (tipo String)
    price: Number,          // Precio del producto (tipo Number)
    imgURL: String          // URL de la imagen del producto (tipo String)
}, {
    timestamps: true,       // Se añade la fecha de creación y actualización automáticamente
    versionKey: false       // Se omite el campo "__v" que Mongoose añade por defecto
});

// Exportación del modelo de Producto con el esquema definido
export default model("Product", productSchema);

