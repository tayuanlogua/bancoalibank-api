import mongoose from "mongoose";
import bcrypt from "bcryptjs";

// Definición del esquema de mongoose para el modelo de usuario
const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      unique: true, // El nombre de usuario debe ser único
    },
    email: {
      type: String,
      unique: true, // La dirección de correo electrónico debe ser única
    },
    password: {
      type: String,
      required: true, // La contraseña es obligatoria
    },
    roles: [
      {
        type: mongoose.Schema.Types.ObjectId, // Referencia a los roles del usuario
        ref: "Role", // Referencia al modelo de roles
      },
    ],
  },
  {
    timestamps: true, // Se añadirán campos de timestamps (createdAt, updatedAt)
    versionKey: false, // Se eliminará el campo "__v"
  }
);

// Función estática para cifrar la contraseña del usuario
userSchema.statics.encryptPassword = async (password) => {
  const salt = await bcrypt.genSalt(10); // Generar un salt para cifrar la contraseña
  return await bcrypt.hash(password, salt); // Cifrar la contraseña con el salt
};

// Función estática para comparar la contraseña proporcionada con la contraseña almacenada
userSchema.statics.comparePassword = async (password, storedPassword) => {
  return await bcrypt.compare(password, storedPassword); // Comparar las contraseñas
};

// Middleware previo a la función save() para cifrar la contraseña antes de guardarla en la base de datos
userSchema.pre("save", async function (next) {
  const user = this; // Obtener el usuario que está siendo guardado
  if (!user.isModified("password")) { // Verificar si la contraseña ha sido modificada
    return next(); // Si no ha sido modificada, pasar al siguiente middleware
  }
  const hash = await bcrypt.hash(user.password, 10); // Cifrar la contraseña con un salt de 10 rounds
  user.password = hash; // Asignar la contraseña cifrada al usuario
  next(); // Pasar al siguiente middleware o finalizar el proceso de guardado
});

// Crear y exportar el modelo de mongoose para el usuario
export default mongoose.model("User", userSchema);
