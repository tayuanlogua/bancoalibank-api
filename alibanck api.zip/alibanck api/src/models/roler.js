import mongoose from "mongoose";

// Definición de los roles predefinidos
export const ROLES = ["user", "admin", "moderator"];

// Esquema de mongoose para el modelo de roles
const roleSchema = new mongoose.Schema(
  {
    name: String, // Campo para el nombre del rol
  },
  {
    versionKey: false, // Evitar la inclusión del campo "__v"
  }
);

// Crear y exportar el modelo de mongoose para los roles
export default mongoose.model("Role", roleSchema);
