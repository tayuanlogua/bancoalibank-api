import { Router} from "express";
const router = Router()

import *as productsCtrl from "../controllers/products.controllers"
router.post("/",productsCtrl.createProduct)

router.get("/",productsCtrl.getProducts)

router.get("/:productId",productsCtrl.getProductByIdd)

router.put(":productId",productsCtrl.updateProductById)

router.delete("/:productId",productsCtrl.deleteProductById)

export default router;