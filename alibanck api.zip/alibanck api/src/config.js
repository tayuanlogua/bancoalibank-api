import { config } from "dotenv";
config(); // Configurar dotenv para cargar variables de entorno desde un archivo .env

// Exportar la URL de conexión a MongoDB, usando la variable de entorno MONGODB_URI si está definida, de lo contrario, una URL de conexión de ejemplo
export const MONGODB_URI =
  process.env.MONGODB_URI || "mongodb+srv://tayuanlogua12:pZA5Py6g7l3ZAOkv@cluster0.m7xjbcr.mongodb.net/";

// Exportar el número de puerto en el que se ejecutará el servidor, usando la variable de entorno PORT si está definida, de lo contrario, el puerto 4000
export const PORT = process.env.PORT || 4000;

// Exportar la clave secreta utilizada para firmar y verificar tokens JWT
export const SECRET = "yoursecretkey";

// Exportar el correo electrónico del administrador, utilizando la variable de entorno ADMIN_EMAIL si está definida, de lo contrario, un valor de ejemplo
export const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@localhost";

// Exportar el nombre de usuario del administrador, utilizando la variable de entorno ADMIN_USERNAME si está definida, de lo contrario, un valor de ejemplo
export const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";

// Exportar la contraseña del administrador, utilizando la variable de entorno ADMIN_PASSWORD si está definida, de lo contrario, un valor de ejemplo
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin";
