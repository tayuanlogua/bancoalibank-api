// Importar los modelos y la configuración necesaria
import User from "../models/User.js";
import Role from "../models/Role.js";
import mongoose from "mongoose";
import bcrypt from "bcrypt";

// Conexión a la base de datos MongoDB
mongoose.connect("mongodb://localhost:27017/tu_base_de_datos", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Función para crear un nuevo usuario
const createUser = async (userData) => {
  try {
    const { username, email, password, roles } = userData;

    // Buscar los roles correspondientes en la base de datos
    const rolesFound = await Role.find({ name: { $in: roles } });

    // Crear un nuevo objeto de usuario
    const user = new User({
      username,
      email,
      password,
      roles: rolesFound.map((role) => role._id),
    });

    // Encriptar la contraseña
    user.password = await bcrypt.hash(user.password, 10);

    // Guardar el nuevo usuario en la base de datos
    const savedUser = await user.save();

    console.log("Usuario creado exitosamente:", savedUser);
  } catch (error) {
    console.error("Error al crear el usuario:", error);
  }
};

// Función para obtener todos los usuarios
const getUsers = async () => {
  try {
    const users = await User.find();
    console.log("Usuarios encontrados:", users);
  } catch (error) {
    console.error("Error al obtener los usuarios:", error);
  }
};

// Función para obtener un usuario por su ID
const getUser = async (userId) => {
  try {
    const user = await User.findById(userId);
    console.log("Usuario encontrado:", user);
  } catch (error) {
    console.error("Error al obtener el usuario:", error);
  }
};

// Ejemplo de uso de las funciones
// Para crear un nuevo usuario
createUser({
  username: "ejemplo",
  email: "ejemplo@example.com",
  password: "password123",
  roles: ["user"],
});

// Para obtener todos los usuarios
getUsers();

// Para obtener un usuario por su ID
getUser("ID_DEL_USUARIO");

