// Importar las dependencias necesarias
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import Role from "../models/Role.js";
import { SECRET } from "../config.js";

// Función para simular una solicitud de registro
const signup = async (userData) => {
  try {
    const { username, email, password, roles } = userData;

    // Crear un nuevo objeto de usuario
    const newUser = new User({
      username,
      email,
      password,
    });

    // Verificar si se proporcionaron roles
    if (roles) {
      const foundRoles = await Role.find({ name: { $in: roles } });
      newUser.roles = foundRoles.map((role) => role._id);
    } else {
      const role = await Role.findOne({ name: "user" });
      newUser.roles = [role._id];
    }

    // Guardar el nuevo usuario en la base de datos
    const savedUser = await newUser.save();

    // Generar un token JWT
    const token = jwt.sign({ id: savedUser._id }, SECRET, {
      expiresIn: 86400, // 24 horas
    });

    console.log("Usuario registrado exitosamente.");
    console.log("Token generado:", token);
  } catch (error) {
    console.error("Error al registrar el usuario:", error.message);
  }
};

// Función para simular una solicitud de inicio de sesión
const signin = async (email, password) => {
  try {
    // Buscar el usuario por su correo electrónico
    const userFound = await User.findOne({ email }).populate("roles");

    if (!userFound) {
      console.error("Usuario no encontrado.");
      return;
    }

    // Verificar la contraseña
    const matchPassword = await User.comparePassword(
      password,
      userFound.password
    );

    if (!matchPassword) {
      console.error("Contraseña inválida.");
      return;
    }

    // Generar un token JWT
    const token = jwt.sign({ id: userFound._id }, SECRET, {
      expiresIn: 86400, // 24 horas
    });

    console.log("Inicio de sesión exitoso.");
    console.log("Token generado:", token);
  } catch (error) {
    console.error("Error al iniciar sesión:", error.message);
  }
};

// Ejemplo de uso
// Para registrar un usuario
signup({
  username: "ejemplo",
  email: "ejemplo@example.com",
  password: "password123",
});

// Para iniciar sesión
signin("ejemplo@example.com", "password123");
