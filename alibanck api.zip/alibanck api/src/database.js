  import mongoose from "mongoose";
import { MONGODB_URI } from "./config.js"; // Importar la URL de conexión a MongoDB desde el archivo de configuración

// Función asincrónica para conectar con la base de datos MongoDB
const connectToDatabase = async () => {
  try {
    // Intentar conectar a la base de datos utilizando la URL de conexión
    const db = await mongoose.connect(MONGODB_URI);
    // Si la conexión es exitosa, imprimir un mensaje indicando que la conexión se realizó correctamente
    console.log("Database is connected to", db.connection.name);
  } catch (error) {
    // Si ocurre un error durante la conexión, imprimir el mensaje de error
    console.error(error.message);
  }
};

// Llamar a la función para conectar a la base de datos
connectToDatabase();
