import app from "./app.js"; // Importar la aplicación Express desde el archivo app.js
import "./database.js"; // Importar la conexión a la base de datos MongoDB desde el archivo database.js
import { PORT } from "./config.js"; // Importar el número de puerto desde el archivo de configuración
import "./libs/initialSetup.js"; // Importar la configuración inicial de la aplicación desde el archivo initialSetup.js

// Iniciar el servidor de la aplicación
const server = app.listen(PORT, () => {
  // Cuando el servidor se inicia correctamente, imprimir un mensaje indicando el puerto en el que está escuchando
  console.log("Server is running on port", server.address().port);
});
//manejo de errores en el servidor

