// app.js

import express from "express";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";

// Routes
import indexRoutes from "./routes/index.routes.js";
import productRoutes from "./routes/products.routes.js";
import usersRoutes from "./routes/user.routes.js";
import authRoutes from "./routes/auth.routes.js";

const app = express();

// Settings
app.set("port", process.env.PORT || 3000); // Configuración del puerto del servidor
app.set("json spaces", 4); // Configuración para la visualización de JSON con 4 espacios de sangría

// Middlewares
app.use(
  cors({
    // origin: "http://localhost:3000", // Configuración de CORS para permitir peticiones desde el origen http://localhost:3000
  })
); // Middleware para configurar CORS
app.use(helmet()); // Middleware para configurar medidas de seguridad de HTTP con Helmet
app.use(morgan("dev")); // Middleware para el registro de solicitudes HTTP con Morgan en modo de desarrollo
app.use(express.json()); // Middleware para analizar solicitudes JSON
app.use(express.urlencoded({ extended: false })); // Middleware para analizar solicitudes de formulario codificadas en url

// Routes
app.use("/api", indexRoutes); // Middleware para manejar las rutas base
app.use("/api/products", productRoutes); // Middleware para manejar las rutas relacionadas con los productos
app.use("/api/users", usersRoutes); // Middleware para manejar las rutas relacionadas con los usuarios
app.use("/api/auth", authRoutes); // Middleware para manejar las rutas relacionadas con la autenticación

export default app; // Exportar la aplicación Express

